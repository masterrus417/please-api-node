export declare const JWT_TOKEN: string;
export declare const base_url: string;
