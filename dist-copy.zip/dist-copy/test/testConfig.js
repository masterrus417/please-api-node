"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.base_url = exports.JWT_TOKEN = void 0;
exports.JWT_TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NCwidXNlcm5hbWUiOiJtYXN0ZXJydXM0MTciLCJpYXQiOjE3MTYzOTM1ODYsImV4cCI6MTcxNjM5NzE4Nn0.1YKYc1amM_HOV--7VYZeeJ4NOptcMv9uWnsMikfJCXA";
exports.base_url = "http://localhost:3000";
