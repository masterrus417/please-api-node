"use strict";
//интерфейсы для работы с авторизацией
Object.defineProperty(exports, "__esModule", { value: true });
