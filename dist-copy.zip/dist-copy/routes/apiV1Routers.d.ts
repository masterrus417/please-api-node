declare const apiV1: import("express-serve-static-core").Router;
export default apiV1;
