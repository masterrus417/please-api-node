declare const userRouter: import("express-serve-static-core").Router;
export default userRouter;
