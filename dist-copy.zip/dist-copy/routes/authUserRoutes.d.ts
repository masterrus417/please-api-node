declare const authUserRouter: import("express-serve-static-core").Router;
export default authUserRouter;
