import { Request, Response } from "express";
export declare const getFilter: (req: Request, res: Response) => Promise<void>;
export declare const getFilterParamsByTypeName: (req: Request, res: Response) => Promise<void>;
