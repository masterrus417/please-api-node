import { Request, Response } from "express";
export declare const getHistory: (req: Request, res: Response) => Promise<void>;
