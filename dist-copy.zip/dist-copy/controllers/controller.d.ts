import { Request, Response } from 'express';
export declare const getUsers: (req: Request, res: Response) => void;
export declare const getUserById: (req: Request, res: Response) => void;
