import { Request, Response } from "express";
export declare const getEntityLinks: (req: Request, res: Response) => Promise<void>;
export declare const createEntityLink: (req: Request, res: Response) => Promise<void>;
export declare const deleteEntityLink: (req: Request, res: Response) => Promise<void>;
