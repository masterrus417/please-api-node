"use strict";
// config/config.js
module.exports = {
    secretKey: 'mySuperSecretKey',
};
