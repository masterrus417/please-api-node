import { Application } from "express";
declare const app: Application;
export default app;
